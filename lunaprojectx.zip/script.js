const SUPABASE_URL = "https://qslfgjasizcayrrcqjdp.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFzbGZnamFzaXpjYXlycmNxamRwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ2MTU5MjUsImV4cCI6MjA3MDE5MTkyNX0.u7bGrxlycZZi8jBPk1Y5qM79PvXfIAaJ5jmjvp6CjxY";

const _supabase = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

async function uploadFile() {
    const fileInput = document.getElementById("fileInput");
    const file = fileInput.files[0];
    if (!file) {
        alert("Pilih file terlebih dahulu!");
        return;
    }

    const { data, error } = await _supabase.storage
        .from("bucket-pertama")
        .upload(file.name, file, {
            cacheControl: "3600",
            upsert: false
        });

    if (error) {
        alert("Gagal upload: " + error.message);
    } else {
        alert("Berhasil upload: " + file.name);
    }
}